#!/usr/bin/env python3
'''
Std. no: 2778835
'''

from typing import List, Tuple



def find_paths(start_id: int, end_id: int, data: List[Tuple[int, List[int]]]
               ) -> List[List[int]]:
    """
    TODO: Implement the multi-path finding method.

    ### Parameters
    start_id : int
        ID of the starting node
    end_id : int
        ID of the target node
    data : list[tuple[int, list[int]]]
        List of tuples of the twitter user data (id:int, following:list[int])
            e.g. [(1, [2, 3]), (2, [3, 1]), (3, [2])]

    ### Returns
    list[list[int]]: List of lists of the node id **as integers**
        of the paths found between the start and end nodes.
    """

    # Step 1: Create and store the graph
    graph = {}
    for id, following in data:
        if id not in graph:
            graph[id] = []
        graph[id].extend(following)

    # Step 2: Define the find function
    def find(start_id, end_id, path, all_paths):
        if start_id == end_id:
            all_paths.append(path.copy())
            return

        if start_id not in graph:
            return

        for neighbor in graph[start_id]:
            if neighbor not in path:
                path.append(neighbor)
                find(neighbor, end_id, path, all_paths)
                path.pop()

    # Step 3: Call the find function with the parameters
    all_paths = []
    find(start_id, end_id, [start_id], all_paths)

    # Step 4: Return a list of lists of node IDs
    return all_paths

# # Example usage:
# if __name__ == "__main__":
#     data = [(1, [2, 3]), (2, [3, 1]), (3, [2])]
#     start_id = 1
#     end_id = 3
#     result = find_paths(start_id, end_id, data)
#     print(result)  # Expected Output: [[1, 3], [1, 2, 3]] (order may vary)
