#!/usr/bin/env python3

'''
Std. no: 2778835
'''

from typing import List, Tuple, Dict

class Node:
    def __init__(self, weight: int):
        self.weight = weight
        self.following = []

def dijkstra(start_id: int, graph: Dict[int, Dict[int, float]]) -> Tuple[List[int], int]:
    visited = set()
    distance = {node_id: float('inf') for node_id in graph}
    previous = {node_id: None for node_id in graph}

    distance[start_id] = 0

    while len(visited) < len(graph):
        min_distance_node = None
        for node_id in graph:
            if node_id not in visited and (min_distance_node is None or distance[node_id] < distance[min_distance_node]):
                min_distance_node = node_id

        if min_distance_node is None:
            break

        visited.add(min_distance_node)

        for neighbor, weight in graph[min_distance_node].items():
            if distance[min_distance_node] + weight < distance[neighbor]:
                distance[neighbor] = distance[min_distance_node] + weight
                previous[neighbor] = min_distance_node

    # Here we will reconstruct the shortest path
    path = []
    current_node = start_id
    while current_node is not None:
        path.append(current_node)
        current_node = previous[current_node]

    path.reverse()
    total_cost = distance[start_id]

    return path, total_cost

def shortest_path(start: int, target: int, data: List[Tuple[int, int, List[int]]]) -> List[int]:
    # Create a graph represented as an adjacency list
    graph = {}
    for node, _, follows in data:
        graph[node] = follows

    # Here we will perform a breadth-first search (BFS) to find the shortest path
    visited = set()
    queue = [(start, [])]

    while queue:
        node, path = queue.pop(0)
        if node == target:
            return path + [node]

        if node not in visited:
            visited.add(node)
            for neighbor in graph.get(node, []):
                queue.append((neighbor, path + [node]))

    # Here, if no path is found, the function will return an empty list
    return []

# # Here we will test the shortest_path function with sample data
# data = [
#     (1, 0, [2, 3]),
#     (2, 0, [4]),
#     (3, 0, [5]),
#     (4, 0, [6]),
#     (5, 0, [6]),
#     (6, 0, [])
# ]

# start_node = 1
# target_node = 6
# result = shortest_path(start_node, target_node, data)
# print(result)  # Should print [1, 2, 4, 6] as the shortest path
