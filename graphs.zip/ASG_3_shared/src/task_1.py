#!/usr/bin/env python3
'''
Std. no: 2778835
'''

import sys
from typing import List, Tuple


def find(start_id: int, end_id: int, graph: dict, visited: set) -> List[int]:
    '''
    TODO: Implement the actual path finding find function.
    Add the parameters you need.
    '''
    if start_id == end_id:
        return [start_id]

    if start_id in visited:
        return []  # Node has been visited, no need to explore further

    visited.add(start_id)

    for neighbor in graph.get(start_id, []):
        path = find(neighbor, end_id, graph, visited)
        if path:
            return [start_id] + path

    return []  # Here, the function will return an empty list if no path is found

# Here we will increase Python's recursion limit
sys.setrecursionlimit(10 ** 6)


def find_path(start_id: int, end_id: int, data: List[Tuple[int, List[int]]]) -> List[int]:
    """
    TODO: Implement the find_path function.

    ### Parameters
    start_id : int
        ID of the starting node
    end_id : int
        ID of the target node
    data : list[tuple[int, list[int]]]
        List of tuples of the twitter user data (id:int, following:list[int])
            e.g. [(1, [2]), (2, [3]),(3, [4]), (4, [5]), (5,[])]

    ### Returns
    list[int]: List of the node id **as integers**
        of the path found between the start and end nodes
    """
    graph = {}  # Here we will create an empty graph as a dictionary
    for user_id, following_ids in data:
        graph[user_id] = following_ids  # Build the directed graph

    visited = set()
    path = find(start_id, end_id, graph, visited)

    if path:
        return path
    else:
        return []

# # Here we will test locally with some example usage:
# if __name__ == "__main__":
#     data = [(1, [2]), (2, [3]), (3, [4]), (4, [5]), (5, [])]
#     start_id = 1
#     end_id = 5
#     result = find_path(start_id, end_id, data)
#     print(result)  # Output should be [1, 2, 3, 4, 5]
#
# data = [(1, [2]), (2, [3]), (3, []), (4, []), (5, [])]
# start_id = 1
# end_id = 4
# result = find_path(start_id, end_id, data)
# print(result)  # Expected Output: []
#
# data = [(1, [2]), (2, [3]), (3, []), (4, []), (5, [])]
# start_id = 3
# end_id = 3
# result = find_path(start_id, end_id, data)
# print(result)  # Expected Output: [3]
#
# data = [(1, [2, 3]), (2, [4]), (3, [5]), (4, [5]), (5, [])]
# start_id = 1
# end_id = 5
# result = find_path(start_id, end_id, data)
# print(result)  # Expected Output: [1, 3, 5] (other valid paths: [1, 2, 4, 5])

