from typing import List, Tuple, Union


class Timeout(Exception):
    def __init__(self, time_limit, exec_time):
        super().__init__(f"Execution took {round(exec_time,4)}s, \
                          expected {time_limit}s")


class NoOutput(Exception):
    def __init__(self):
        super().__init__("Function did not return anything. "
                         "Did you return your result?")


class WrongType(Exception):
    def __init__(self, type):
        super().__init__("Function returned wrong type. "
                         f"Expected type: {type}")


class WrongSize(Exception):
    def __init__(self, expected: int, got: int):
        super().__init__(f"Function returned {got}/{expected} answers.")


class WrongAnswer(Exception):
    def __init__(self, result_l: List[int], answer_l: List[int]):
        msg = ''
        if len(result_l) != len(answer_l):
            msg = msg + f"Wrong size, {len(result_l)} != {len(answer_l)}.\n"

        diff = []
        for index, (o, a) in enumerate(zip(result_l, answer_l)):
            if o != a:
                diff.append((index, o, a))

        if len(diff) > 50:  # Change this or larger outputs.
            msg = msg + f"Too many diffs ({len(diff)}) to print in console."
        elif len(diff) > 0:
            msg = msg + "Differences by index: "
            msg = msg + ', '.join(f"{i}:{o}=>{a}" for i, o, a in diff)

        super().__init__(msg)


class WrongAnswerTask2(Exception):
    def __init__(self, output_l: List[List[int]],
                 answer_l: List[List[int]], correct: int):
        msg = "Wrong answer. " + \
              f"Found {len(output_l)}/{len(answer_l)} paths " + \
              f"from which {correct} are correct."

        super().__init__(msg)


class WrongAnswerBonus(Exception):
    def __init__(self, output: Tuple[int, Union[int, bool],
                                     float, List[int]],
                 index: int):
        super().__init__(f"Wrong answer at index {index}: {output}")
