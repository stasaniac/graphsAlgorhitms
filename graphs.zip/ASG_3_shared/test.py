#!/usr/bin/env python3

from typing import Callable, List, Tuple
import time
import pytest
import logging
from os import path

import cg_pytest_reporter as cg_pytest

from src import task_1, task_2, task_3
import error


logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger('logger')
root_dir = path.dirname(path.abspath(__file__))


@pytest.mark.task_1
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 1')
@cg_pytest.suite_weight(0.75)
class TestTask1:
    '''
    Task 1 worth 3 points
    '''

    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[int, int, List[Tuple[int, List[int]]]],
                           List[int]]):

        # Open test files and prepare input/answer data
        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer = open(f"{root_dir}/{testcase}.ans", "r").readline()
        answer_l: List[int] = [int(e) for e in answer.split(' ')]

        # Create `result_l: list[tuple[int,list[int]]]` from the test file data
        data: str = input_file.read()
        path, data = data.split('\n', 1)
        # Fetch start and target node ids
        start, target = [int(x) for x in path.split(' ')]
        data_l: List = data.split('; ')
        input_l: List[Tuple[int, List[int]]] = []
        for d in data_l:
            id, following_str = d.split(', ', 1)
            fs_l: List[str] = following_str.split(', ')

            # Handle not following case
            following_l: List[int] = [] if fs_l == [''] \
                else list(map(int, fs_l))
            input_l.append((int(id), following_l))

        # Run the `find_path` function and measure execution time
        start_time = time.time()
        result_l: List[int] = func(int(start), int(target), input_l)
        end_time = time.time()

        # Check that execution time is not above limit
        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.info(f'Call to {func.__name__} took {exec_time}s')

        # Check that `find_path` returned an !empty object
        if result_l is None:
            raise error.NoOutput()

        # Check that result is a list[int]
        if not isinstance(result_l, list) \
                or not all(isinstance(x, int) for x in result_l):
            raise error.WrongType(List[int])

        # Check answer
        if result_l != answer_l:
            raise error.WrongAnswer(result_l, answer_l)

    @cg_pytest.description('Between 10 and 30 nodes')
    def test_1(self):
        self.run("testcases/task_1/10_30", 20,
                 task_1.find_path)

    @cg_pytest.description('Between 200 and 400 nodes')
    def test_2(self):
        self.run("testcases/task_1/100_400", 20,
                 task_1.find_path)

    @cg_pytest.description('Between 500 and 4000 nodes')
    def test_3(self):
        self.run("testcases/task_1/500_4000", 20,
                 task_1.find_path)

    @cg_pytest.description('Between 5000 and 20000 nodes')
    def test_4(self):
        self.run("testcases/task_1/5000_20000", 20,
                 task_1.find_path)


@pytest.mark.task_2
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 2')
@cg_pytest.suite_weight(0.75)
class TestTask2:

    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[int, int, List[Tuple[int, List[int]]]],
                           List[List[int]]]):

        # Open test files and prepare input/answer data
        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer = open(f"{root_dir}/{testcase}.ans", "r").read()
        answer_l = [[int(e) for e in a.split(' ')]
                    for a in answer.rstrip().split('\n')]

        # Create `input_l: list[tuple[int,list[int]]]` from the test file data
        data: str = input_file.read()
        path, data = data.split('\n', 1)
        # Fetch start and target node ids
        start, target = [int(x) for x in path.split(' ')]
        data_l: List = data.split('; ')
        input_l: List[Tuple[int, List[int]]] = []
        for d in data_l:
            id, following_str = d.split(', ', 1)
            fs_l: List[str] = following_str.split(', ')

            # Handle not following case
            following_l: List[int] = [] if fs_l == [''] \
                else list(map(int, fs_l))
            input_l.append((int(id), following_l))

        # Run the `find_paths` function and measure execution time
        start_time = time.time()
        result_l: List[List[int]] = func(int(start), int(target), input_l)
        end_time = time.time()

        # Check that execution time is not above limit
        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.info(f'Call to {func.__name__} took {exec_time}s')

        # Check that `find_paths` returned a !empty object
        if result_l is None:
            raise error.NoOutput()

        # Check that result is a 2D list of int: list[list[int]]
        if not isinstance(result_l, list) \
                or not all(isinstance(x, list) for x in result_l) \
                or not all(all(isinstance(i, int)
                               for i in li) for li in result_l):
            raise error.WrongType(List[List[int]])

        # Check that the correct number of solutions were found
        if len(answer_l) != len(result_l):
            raise error.WrongSize(len(answer_l), len(result_l))

        # Check unordered that all possible answers were found
        res: List[bool] = [ans in result_l for ans in answer_l]
        if not all(res):
            raise error.WrongAnswerTask2(result_l, answer_l, res.count(True))

    @cg_pytest.description('5 nodes 10 edges')
    def test_1(self):
        self.run("testcases/task_2/5_10", 20,
                 task_2.find_paths)

    @cg_pytest.description('10 nodes 20 edges')
    def test_2(self):
        self.run("testcases/task_2/10_20",
                 20, task_2.find_paths)

    @cg_pytest.description('50 nodes 100 edges')
    def test_3(self):
        self.run("testcases/task_2/50_100",
                 20, task_2.find_paths)

    @cg_pytest.description('100 nodes 180 edges')
    def test_4(self):
        self.run("testcases/task_2/100_180",
                 20, task_2.find_paths)


@pytest.mark.task_3
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 3')
@cg_pytest.suite_weight(1)
class TestTask3:

    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[int, int, List[Tuple[int, int, List[int]]]],
                           List[int]]):

        # Open test files and prepare input/answer data
        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer = open(f"{root_dir}/{testcase}.ans", "r").readline()
        answer_l: List[int] = [int(e) for e in answer.split(' ')]

        # Create `input_l: list[tuple[int,list[int]]]` from the test file data
        data: str = input_file.read()
        path, data = data.split('\n', 1)
        # Fetch start and target node ids
        start, target = [int(x) for x in path.split(' ')]
        data_l: List = data.split('; ')
        data_l: List = data.split('; ')
        input_l: List[Tuple[int, int, List[int]]] = []
        for d in data_l:
            id, num_likes, following_str = d.split(', ', 2)
            fs_l: List[str] = following_str.split(', ')

            # Handle not following case
            following_l: List[int] = [] if fs_l == [''] \
                else list(map(int, fs_l))
            input_l.append((int(id), int(num_likes), following_l))

        # Run the `shortest_path` function and measure execution time
        start_time = time.time()
        result_l: List[int] = func(int(start), int(target), input_l)
        end_time = time.time()

        # Check that execution time is not above limit
        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.info(f'Call to {func.__name__} took {exec_time}s')

        # Check that `shortest_path` returned a !empty object
        if result_l is None:
            raise error.NoOutput()

        # Check that result is a list[int]
        if not isinstance(result_l, list) \
                or not all(isinstance(x, int) for x in result_l):
            raise error.WrongType(List[int])

        # Check answer
        if result_l != answer_l:
            raise error.WrongAnswer(result_l, answer_l)

    @cg_pytest.description('Between 10 and 20 nodes')
    def test_1(self):
        self.run("testcases/task_3/10_20", 20,
                 task_3.shortest_path)

    @cg_pytest.description('Between 100 and 400 nodes')
    def test_2(self):
        self.run("testcases/task_3/100_400", 20,
                 task_3.shortest_path)

    @cg_pytest.description('Between 500 and 3000 nodes')
    def test_3(self):
        self.run("testcases/task_3/500_3000", 20,
                 task_3.shortest_path)

    @cg_pytest.description('Between 3000 and 12000 nodes')
    def test_4(self):
        self.run("testcases/task_3/3000_12000", 20,
                 task_3.shortest_path)
